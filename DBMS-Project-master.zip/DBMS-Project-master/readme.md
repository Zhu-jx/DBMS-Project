## Database Management Project: Used Car Management System


#### Apr 17 2:03 am

- add Trend 8

#### Apr 17 12:40 am

- finish Trend Page 2-7 form and show
- use various Chart type to display the data: line, bar, dashed, filled, displayLine

```$xslt
http://localhost:8080/dbms/trend2/form
http://localhost:8080/dbms/trend2/show

to

http://localhost:8080/dbms/trend7/form
http://localhost:8080/dbms/trend7/show
```
#### Apr 12 8:43 pm


finish 4 url for testing

search form, search show
trend1 form, trend1 show
```
http://localhost:8080/dbms/search/form
http://localhost:8080/dbms/search/show
http://localhost:8080/dbms/trend1/form
http://localhost:8080/dbms/trend1/show
```